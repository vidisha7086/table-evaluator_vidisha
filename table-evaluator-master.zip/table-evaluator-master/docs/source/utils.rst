Utils
===================
.. toctree::
   :maxdepth: 3
   :caption: Contents:


.. automodule:: table_evaluator.utils
   :members:
