.. table evaluator documentation master file, created by
   sphinx-quickstart on Wed Jun 24 17:45:26 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to table evaluator's documentation!
===========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   table_evaluator
   viz
   metrics
   utils

Welcome to the documentation for TableEvaluator! Please see the contents/sidebar for a high level overview. The library consists of two main parts. First, the TableEvaluator class, which does most of the heavy lifting and then Helper Functions that provide extra functionality and reusable parts for TableEvaluator.

.. mdinclude:: ../../README.md

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
