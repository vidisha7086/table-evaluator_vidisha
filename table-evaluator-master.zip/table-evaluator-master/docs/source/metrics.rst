Metrics
===================
.. toctree::
   :maxdepth: 2
   :caption: Contents:


.. automodule:: table_evaluator.metrics
   :members:
