import pandas as pd
import numpy as np
from table_evaluator import TableEvaluator
from table_evaluator.utils import *


# real, fake = load_data('../data/real_test_sample.csv', '../data/fake_test_sample.csv')

